export const strToArray = (str: any, separetor: string): any[] => {
  return str ? str.split(separetor) : [];
};

export class Ad {}

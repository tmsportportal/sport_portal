export class CreateAdDto {}
